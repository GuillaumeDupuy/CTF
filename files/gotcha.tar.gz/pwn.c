#include <stdio.h>

void check_input(void)
{
	int (*stack_puts) (const char *);
	char input[64];

	stack_puts = puts;

	stack_puts("Gimme a trusted input plz:");
	fgets(input, 80, stdin);

	stack_puts("");

	stack_puts("Wow! Your input is trustable a lot, i'm giving it you back:");
	stack_puts(input);

	stack_puts("See you soon...");
}

int main(void)
{
    setbuf(stdout, NULL);

	puts("========================================");
	puts("======= Hi! Welcome to our very ========");
	puts("=======   sekure 42ctf portal   ========");
	puts("========================================");
	puts("Current date:");
	system("date");
	puts("========================================");

	puts("");
	check_input();

	return 0;
}
