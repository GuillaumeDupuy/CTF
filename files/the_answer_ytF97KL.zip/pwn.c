#include <stdlib.h>
#include <stdio.h>

int main()
{
    int answer = 0;
    char buff[32];

    setbuf(stdout, NULL);

    puts("Give me the answer to life, the universe and everything.");
    gets(buff);
    if (answer == 42)
        system("cat flag.txt");
    else
        puts("Try again. Bye.");
}